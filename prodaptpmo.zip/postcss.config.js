module.exports = {
  plugins: {
    tailwindcss: {},
  },
}
