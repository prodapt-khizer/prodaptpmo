/** @type {import('next').NextConfig} */
const nextConfig = {
  trailingSlash: true,
  // async generateStaticParams() {
  //   return {
  //     "/": { page: "/" },
  //   };
  // },
};

module.exports = nextConfig;
