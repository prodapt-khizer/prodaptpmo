import React from 'react'

const GanttChart = () => {
  return (
    <div>GanttChart</div>
  )
}

export default GanttChart