// import React from 'react'
"use client"; 
const TopBar = () => {
  return (
    <div>TopBar</div>
  )
}

export default TopBar