// import React from 'react'
"use client"; 
const SideBar = () => {
  return (
    <div>SideBar</div>
  )
}

export default SideBar