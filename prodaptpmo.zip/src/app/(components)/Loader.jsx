import React from 'react'
import "../Styles/Loader.css"
const Loader = () => {
  return (
    <div className="loader_container">
        <div className="kinetic"></div>
    </div>
  )
}

export default Loader