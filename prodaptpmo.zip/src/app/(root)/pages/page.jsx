import React from 'react'

const page = () => {
  return (
    <div>hello</div>
  )
}

export default page