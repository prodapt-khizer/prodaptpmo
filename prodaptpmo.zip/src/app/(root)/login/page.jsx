// Assuming you're using 'websocket' library, make sure to install it with `npm install websocket` if you haven't already

"use client";
import LoginPage from "../../(components)/LoginPage";


export default function Login() {
  
  return (
    <main>
      <LoginPage />
    </main>
  );
}
