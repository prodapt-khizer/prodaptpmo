// const { default: mongoose } = require("mongoose");

// export default async mongooseConnect = () =>{
//    return await mongoose.connect(process.env.MONGODB_URI, {
//         bufferCommands: false, // Disable command buffering
//         useNewUrlParser: true,
//         useUnifiedTopology: true,
//       });
// };